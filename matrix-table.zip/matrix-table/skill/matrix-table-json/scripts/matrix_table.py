#!/usr/bin/env python3
"""matrix-table v1 검증기 + HTML 미리보기.

Salesforce Apex `MatrixTableRenderer`와 같은 규칙으로 검증하고 같은 구조의 HTML을 만든다.
Apex로 보내기 전에 에이전트가 JSON을 로컬에서 확인하는 용도.

  python matrix_table.py validate table.json
  python matrix_table.py render table.json -o preview.html
"""
import html, json, re, sys, argparse

ROLES = {"group", "leaf", "spacer"}
KINDS = {"value", "total", "delta"}
TOP_KEYS = {"version", "id", "title", "unit", "grid", "style", "corner", "colHeaders", "rowHeaders", "cells"}
HEADER_KEYS = {"id", "role", "kind", "label", "parent", "owner", "r", "c", "rs", "cs", "b"}
CELL_KEYS = {"r", "c", "rowKey", "colKey", "value", "b"}
GRID_KEYS = {"rows", "cols", "headerRows", "headerCols"}
STYLE_KEYS = {"borderColor", "borderWidth", "headerBg", "fontFamily", "fontSize", "cellPadding", "spacerSize"}
SAFE_CSS = re.compile(r"^[\w#.,%\s'()\-]+$", re.UNICODE)
MAX_ERRORS = 50


class Ctx:
    def __init__(self, spec):
        self.spec = spec
        self.errors = []
        self.col, self.row, self.col_leaf, self.row_leaf = {}, {}, {}, {}

    def err(self, m):
        if len(self.errors) < MAX_ERRORS:
            self.errors.append(m)
        elif len(self.errors) == MAX_ERRORS:
            self.errors.append("... 오류가 너무 많아 이후 항목은 생략합니다.")

    def strict(self, obj, allowed, where):
        if not isinstance(obj, dict):
            self.err(f"{where}: 객체여야 합니다."); return
        for k in obj:
            if k not in allowed:
                self.err(f"{where}: 알 수 없는 키 '{k}' (Apex deserializeStrict에서 실패합니다).")

    @staticmethod
    def norm(h):
        h.setdefault("rs", 1); h.setdefault("cs", 1)
        b = h.setdefault("b", {}) or {}
        h["b"] = {"t": b.get("t", 1) if b.get("t") is not None else 1, "l": b.get("l", 1) if b.get("l") is not None else 1}
        return h

    def claim(self, id_, r, c, rs, cs):
        if r is None or c is None:
            self.err(f"{id_}: r, c는 필수입니다."); return
        if rs < 1 or cs < 1 or r < 0 or c < 0 or r + rs > self.rows or c + cs > self.cols:
            self.err(f"{id_}: grid({self.rows}x{self.cols}) 범위를 벗어났습니다 (r={r}, c={c}, rs={rs}, cs={cs})."); return
        for i in range(r, r + rs):
            for j in range(c, c + cs):
                if self.occ[i][j] is not None:
                    self.err(f"{id_}: (r={i}, c={j})에서 {self.occ[i][j]}와 겹칩니다.")
                else:
                    self.occ[i][j] = id_

    def collect(self):
        s = self.spec
        self.strict(s, TOP_KEYS, "root")
        g = s.get("grid")
        if not g or any(not isinstance(g.get(k), int) for k in GRID_KEYS):
            self.err("grid.rows, grid.cols, grid.headerRows, grid.headerCols는 필수입니다."); return
        self.strict(g, GRID_KEYS, "grid")
        if s.get("style") is not None: self.strict(s["style"], STYLE_KEYS, "style")
        self.rows, self.cols, self.hr, self.hc = g["rows"], g["cols"], g["headerRows"], g["headerCols"]
        if self.hr < 1 or self.hc < 1 or self.hr >= self.rows or self.hc >= self.cols:
            self.err("grid 값이 올바르지 않습니다: 1 <= headerRows < rows, 1 <= headerCols < cols 이어야 합니다."); return
        self.occ = [[None] * self.cols for _ in range(self.rows)]
        cn = s.get("corner")
        if cn is None:
            self.err("corner는 필수입니다.")
        else:
            self.strict(cn, HEADER_KEYS, "corner"); self.norm(cn)
            if cn.get("r") != 0 or cn.get("c") != 0 or cn["rs"] != self.hr or cn["cs"] != self.hc:
                self.err(f"corner는 r=0, c=0, rs=headerRows({self.hr}), cs=headerCols({self.hc}) 이어야 합니다.")
            self.claim("corner", cn.get("r"), cn.get("c"), cn["rs"], cn["cs"])
        self.index(s.get("colHeaders"), self.col, "colHeaders")
        self.index(s.get("rowHeaders"), self.row, "rowHeaders")
        self.check(self.col, True); self.check(self.row, False)
        self.check_cells(); self.coverage()

    def index(self, lst, target, name):
        if not lst:
            self.err(f"{name}가 비어 있습니다."); return
        for h in lst:
            self.strict(h, HEADER_KEYS, f"{name}[{h.get('id')}]"); self.norm(h)
            if not h.get("id"):
                self.err(f"{name}: id가 없는 헤더가 있습니다 (r={h.get('r')}, c={h.get('c')})."); continue
            if h["id"] == "corner" or h["id"] in self.col or h["id"] in self.row:
                self.err(f"헤더 id 중복 또는 예약어: {h['id']}"); continue
            target[h["id"]] = h
            self.claim(h["id"], h.get("r"), h.get("c"), h["rs"], h["cs"])

    def check(self, by, is_col):
        hr, hc = self.hr, self.hc
        for h in by.values():
            tag = h["id"] + ": "
            if h.get("role") not in ROLES:
                self.err(tag + "role은 group | leaf | spacer 중 하나여야 합니다."); continue
            r, c, rs, cs = h.get("r"), h.get("c"), h["rs"], h["cs"]
            if r is None or c is None: continue
            ok = (r >= 0 and r + rs <= hr and c >= hc and c + cs <= self.cols) if is_col else \
                 (c >= 0 and c + cs <= hc and r >= hr and r + rs <= self.rows)
            if not ok:
                self.err(tag + ("열 헤더 영역(r < headerRows, c >= headerCols)" if is_col else "행 헤더 영역(r >= headerRows, c < headerCols)") + "을 벗어났습니다.")
            if h["b"]["t"] not in (0, 1) or h["b"]["l"] not in (0, 1):
                self.err(tag + "b.t, b.l은 0 또는 1이어야 합니다.")
            if h.get("kind") is not None and (h["role"] != "leaf" or h["kind"] not in KINDS):
                self.err(tag + "kind는 leaf에서만 value | total | delta 중 하나로 쓸 수 있습니다.")
            if h["role"] == "leaf":
                if is_col:
                    if r + rs != hr or cs != 1:
                        self.err(tag + f"열 leaf는 cs=1이고 아래 끝이 마지막 헤더 행(r + rs = {hr})에 닿아야 합니다.")
                    elif c in self.col_leaf:
                        self.err(tag + f"c={c} 열에 leaf가 둘 이상입니다 ({self.col_leaf[c]['id']}).")
                    else:
                        self.col_leaf[c] = h
                else:
                    if c + cs != hc or rs != 1:
                        self.err(tag + f"행 leaf는 rs=1이고 오른쪽 끝이 마지막 헤더 열(c + cs = {hc})에 닿아야 합니다.")
                    elif r in self.row_leaf:
                        self.err(tag + f"r={r} 행에 leaf가 둘 이상입니다 ({self.row_leaf[r]['id']}).")
                    else:
                        self.row_leaf[r] = h
            if h["role"] == "spacer":
                if rs != 1 or cs != 1: self.err(tag + "spacer는 rs=1, cs=1이어야 합니다.")
                if h.get("label"): self.err(tag + "spacer는 label을 가질 수 없습니다.")
                o = by.get(h.get("owner") or "")
                if o is None or o.get("role") != "leaf":
                    self.err(tag + f"spacer.owner는 같은 축의 leaf id여야 합니다 (현재: {h.get('owner')}).")
            elif h.get("owner") is not None:
                self.err(tag + "owner는 spacer에서만 쓸 수 있습니다.")
            if h.get("parent") is not None:
                p = by.get(h["parent"])
                if p is None or p.get("role") == "spacer":
                    self.err(tag + f"parent는 같은 축의 group 또는 leaf id여야 합니다 (현재: {h['parent']}).")
                else:
                    seen, cur = {h["id"]}, p
                    while cur is not None:
                        if cur["id"] in seen:
                            self.err(tag + "parent 체인에 순환이 있습니다."); break
                        seen.add(cur["id"]); cur = by.get(cur.get("parent")) if cur.get("parent") else None

    def check_cells(self):
        cells = self.spec.setdefault("cells", []) or []
        self.spec["cells"] = cells
        for d in cells:
            self.strict(d, CELL_KEYS, f"cell(r={d.get('r')}, c={d.get('c')})")
            r, c = d.get("r"), d.get("c"); tag = f"cell(r={r}, c={c}): "
            if r is None or c is None or r < self.hr or r >= self.rows or c < self.hc or c >= self.cols:
                self.err(tag + f"데이터 영역(r >= {self.hr}, c >= {self.hc})을 벗어났습니다."); continue
            rl, cl = self.row.get(d.get("rowKey")), self.col.get(d.get("colKey"))
            if rl is None or rl.get("role") != "leaf" or rl.get("r") != r:
                self.err(tag + f"rowKey({d.get('rowKey')})는 r={r}에 있는 행 leaf여야 합니다.")
            if cl is None or cl.get("role") != "leaf" or cl.get("c") != c:
                self.err(tag + f"colKey({d.get('colKey')})는 c={c}에 있는 열 leaf여야 합니다.")
            if not isinstance(d.get("value", ""), str):
                self.err(tag + "value는 문자열이어야 합니다 (예: \"1,250\", \"+3.2%\").")
            b = d.get("b")
            if b is not None and (b.get("t") not in (0, 1) or b.get("l") not in (0, 1)):
                self.err(tag + "b를 지정할 경우 t, l 모두 0 또는 1이어야 합니다.")
            self.claim(f"cell({r},{c})", r, c, 1, 1)

    def coverage(self):
        for i in range(self.rows):
            for j in range(self.cols):
                if self.occ[i][j] is None:
                    self.err(f"(r={i}, c={j}) 위치를 덮는 셀이 없습니다.")

    # ---------- HTML ----------
    def to_html(self):
        st = self.spec.get("style") or {}
        def css(k, d):
            v = st.get(k)
            return v if isinstance(v, str) and v.strip() and SAFE_CSS.match(v) else d
        bc, bw, hbg = css("borderColor", "#bfbdb5"), css("borderWidth", "1px"), css("headerBg", "#f5f4ef")
        ff = css("fontFamily", "'Malgun Gothic','Apple SD Gothic Neo',Arial,sans-serif")
        fs, pad = css("fontSize", "12px"), css("cellPadding", "6px 8px")
        sp = st.get("spacerSize") if isinstance(st.get("spacerSize"), int) and st.get("spacerSize") >= 1 else 12
        e = lambda s: html.escape(s or "", quote=True)
        edge = lambda on: f"{bw} solid {bc if on == 1 else 'transparent'}"
        hstyle = lambda a: f"padding:{pad};background:{hbg};font-weight:bold;white-space:nowrap;text-align:{a};vertical-align:middle;"
        def cell(tag, rs, cs, t, l, style, attrs, content):
            return (f"<{tag}" + (f' rowspan="{rs}"' if rs > 1 else "") + (f' colspan="{cs}"' if cs > 1 else "")
                    + attrs + f' style="border-top:{edge(t)};border-left:{edge(l)};{style}">{content}</{tag}>')
        slots = [[None] * self.cols for _ in range(self.rows)]
        cn = self.spec["corner"]
        slots[0][0] = cell("th", cn["rs"], cn["cs"], cn["b"]["t"], cn["b"]["l"], hstyle("center"), ' data-id="corner"', e(cn.get("label")))
        for by, is_col in ((self.col, True), (self.row, False)):
            for h in by.values():
                attrs = (f' data-id="{e(h["id"])}" data-axis="{"col" if is_col else "row"}" data-role="{e(h["role"])}"'
                         + (f' data-parent="{e(h["parent"])}"' if h.get("parent") else "")
                         + (f' data-owner="{e(h["owner"])}"' if h.get("owner") else "")
                         + (f' data-kind="{e(h["kind"])}"' if h.get("kind") else ""))
                if h["role"] == "spacer":
                    size = (f"height:{sp}px;padding:0;font-size:0;line-height:0;" if is_col else f"width:{sp}px;min-width:{sp}px;padding:0;")
                    slots[h["r"]][h["c"]] = cell("td", 1, 1, h["b"]["t"], h["b"]["l"], size + f"background:{hbg};", attrs + ' aria-hidden="true"', "")
                else:
                    align = "left" if (not is_col and h["role"] == "leaf") else "center"
                    scope = ("colgroup" if h["cs"] > 1 else "col") if is_col else ("rowgroup" if h["rs"] > 1 else "row")
                    slots[h["r"]][h["c"]] = cell("th", h["rs"], h["cs"], h["b"]["t"], h["b"]["l"], hstyle(align), f' scope="{scope}"' + attrs, e(h.get("label")))
        for d in self.spec["cells"]:
            rl, cl = self.row[d["rowKey"]], self.col[d["colKey"]]
            b = d.get("b")
            t, l = (b["t"], b["l"]) if b else (rl["b"]["t"], cl["b"]["l"])
            attrs = (f' data-r="{d["r"]}" data-c="{d["c"]}" data-row="{e(d["rowKey"])}" data-col="{e(d["colKey"])}"'
                     + (f' data-kind="{e(cl["kind"])}"' if cl.get("kind") else ""))
            slots[d["r"]][d["c"]] = cell("td", 1, 1, t, l, f"padding:{pad};text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums;", attrs, e(d.get("value")))
        s = self.spec
        out = ['<div style="overflow-x:auto">',
               f'<table style="border-collapse:separate;border-spacing:0;border-right:{edge(1)};border-bottom:{edge(1)};font-family:{ff};font-size:{fs};color:#1f1f1f"'
               + (f' data-table-id="{e(s["id"])}"' if s.get("id") else "") + ">"]
        if s.get("title") or s.get("unit"):
            out.append('<caption style="caption-side:top;text-align:left;padding:0 0 6px;font-weight:bold">' + e(s.get("title"))
                       + (f' <span style="font-weight:normal;color:#666">(단위: {e(s["unit"])})</span>' if s.get("unit") else "") + "</caption>")
        for i in range(self.rows):
            out.append('<tr data-section="head">' if i < self.hr else "<tr>")
            out.extend(x for x in slots[i] if x is not None)
            out.append("</tr>")
        out.append("</table></div>")
        return "".join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["validate", "render"])
    ap.add_argument("path")
    ap.add_argument("-o", "--out")
    a = ap.parse_args()
    try:
        spec = json.load(open(a.path, encoding="utf-8"))
    except Exception as ex:
        print(f"JSON 파싱 실패: {ex}"); sys.exit(1)
    ctx = Ctx(spec); ctx.collect()
    if ctx.errors:
        print(f"검증 실패 ({len(ctx.errors)}건)"); print("\n".join(ctx.errors)); sys.exit(1)
    if a.cmd == "validate":
        print(f"OK  grid={spec['grid']}  colHeaders={len(spec['colHeaders'])}  rowHeaders={len(spec['rowHeaders'])}  cells={len(spec['cells'])}")
        return
    page = '<!doctype html><meta charset="utf-8"><body style="padding:16px;background:#fff">' + ctx.to_html() + "</body>"
    if a.out:
        open(a.out, "w", encoding="utf-8").write(page); print(f"written {a.out}")
    else:
        print(page)

if __name__ == "__main__":
    main()
