---
name: matrix-table-json
description: 병합 헤더가 있는 복잡한 표(분기/연도별 실적표, 회사·사업부·제품별 지표 표 등)를 matrix-table v1 JSON 메타데이터로 작성한다. 이 JSON은 Salesforce Apex `MatrixTableRenderer`가 HTML table로 렌더링한다. 사용자가 실적표, 분기 비교표, QoQ/YoY 표, 다단 헤더 표, 병합 셀 표를 만들어 달라고 하거나, MatrixTableRenderer에 넘길 JSON, 표 메타데이터, 셀 좌표 JSON을 요청하면 반드시 이 스킬을 사용한다. 표 모양을 말로만 설명해도 결과물이 이 JSON이어야 하면 사용한다.
---

# matrix-table v1 JSON 작성 가이드

결과물은 **하나의 JSON 객체**다. Apex `MatrixTableRenderer.render(json)`이 이를 검증해 HTML `<table>`로 만든다.
검증이 엄격하므로(알 수 없는 키, 겹침, 빈 칸 모두 오류) 아래 규칙을 그대로 따르고, 제출 전 반드시 검증 스크립트를 돌린다.

## 1. 핵심 개념

**격자 좌표.** 표 전체가 `rows × cols` 격자이고 모든 셀은 `(r, c)` 원점과 `rs`(rowspan), `cs`(colspan)를 가진다. 0부터 센다.
격자의 모든 칸은 정확히 한 셀이 덮어야 한다(빈 칸, 겹침 모두 오류).

```
 r < headerRows, c < headerCols   → corner (1개, 좌상단 전체)
 r < headerRows, c >= headerCols  → colHeaders (열 헤더 영역)
 r >= headerRows, c < headerCols  → rowHeaders (행 헤더 영역)
 r >= headerRows, c >= headerCols → cells (데이터 영역)
```

**테두리 소유 규칙.** 각 셀은 자기 **위쪽(t)과 왼쪽(l)** 테두리만 가진다. `b: {"t":1,"l":1}`이 기본값이고 0이면 그 선을 숨긴다.
표의 오른쪽/아래 외곽선은 렌더러가 그린다. 따라서 c=0 셀의 `l`과 r=0 셀의 `t`가 표의 왼쪽/위 외곽선이다. 이 둘은 항상 1로 둔다.

**spacer로 소속 표현.** 상위 헤더와 리프 헤더 사이에 얇은 spacer 행(열 헤더) 또는 spacer 열(행 헤더)을 둔다.
spacer는 `owner`(소속 리프)를 가지며, spacer의 t/l 선을 켜고 끄는 것으로 "이 리프가 상위 헤더에 붙어 있는지", "옆 리프의 확장 영역 아래에 매달려 있는지"를 시각적으로 표현한다.

**데이터 셀 테두리 상속.** 데이터 셀의 `b`를 생략하면 `t`는 그 행 leaf 헤더의 `b.t`, `l`은 그 열 leaf 헤더의 `b.l`을 그대로 쓴다.
그래서 행/열 전체의 선은 헤더 플래그 하나로 제어한다. 데이터 셀 `b`는 예외적인 경우에만 쓴다.

## 2. 표준 레이아웃

| 축 | 구성 | 값 |
|---|---|---|
| 열 헤더 | r0 상위(연도) / r1 spacer / r2 리프(분기, 계, QoQ, YoY) | `headerRows = 3` |
| 행 헤더 | c0 상위(회사·지표 그룹) / c1 spacer / c2 리프(항목) | `headerCols = 3` |
| 행 헤더(그룹 없음) | c0 spacer / c1 리프 | `headerCols = 2` |

- spacer는 **리프마다 하나씩** 둔다(열 spacer는 r1에 리프 열 수만큼, 행 spacer는 리프 행 수만큼). 항상 `rs=1, cs=1`, `label` 없음.
- 리프는 열이면 `cs=1`이고 마지막 헤더 행(r2)에, 행이면 `rs=1`이고 마지막 헤더 열에 있어야 한다. 열 하나·행 하나당 리프는 정확히 하나다.
- 상위(group)는 자기 아래 리프 전체를 `cs`(열) 또는 `rs`(행)로 덮는다.

## 3. 패턴 레시피 (t/l 값을 그대로 복사)

### 열 헤더

| 패턴 | spacer (r1) | leaf (r2) | 비고 |
|---|---|---|---|
| 일반 분기 (1Q~4Q) | `owner=리프, t:1, l:1` | `t:0, l:1`, `parent=연도` | spacer와 리프가 한 셀처럼 보이고 연도와는 선으로 분리 |
| 계 (연도에 직접 붙음) | `owner=계, t:0, l:1` | `t:0, l:1`, `kind:"total"`, `parent=연도` | 연도 셀과 계 사이 선 없음 |
| 기간 하위 지표 (QoQ, YoY) | `owner=기준 리프, t:기준 리프 spacer와 동일, l:0` | `t:1, l:1`, `kind:"delta"`, `parent=기준 리프` | 기준 리프 영역이 ㄱ자로 확장되고 delta가 그 아래에 매달림 |

기준 리프 하나에 delta 여러 개(QoQ + YoY)를 붙일 때는 delta마다 spacer를 하나씩, 모두 `owner=기준 리프, l:0`으로 이어 붙인다.
`계` 아래에 YoY를 붙이면 계의 spacer가 `t:0`이므로 YoY spacer도 `t:0, l:0`이다(연도 → 계 → YoY가 하나로 이어짐).

### 행 헤더 (열 헤더 규칙의 t ↔ l 전치)

| 패턴 | spacer (c1) | leaf (c2) | 비고 |
|---|---|---|---|
| 일반 항목 | `owner=리프, t:1, l:1` | `t:1, l:0`, `parent=그룹` | spacer와 리프가 한 셀처럼 보임 |
| 하위 항목 (매출 아래 QCT, QTL) | `owner=상위 항목, t:0, l:1` | `t:1, l:1`, `parent=상위 항목` | 상위 항목 영역이 아래로 확장되고 하위 항목이 그 오른쪽에 매달림 |
| 위 행과 결합 (영업이익 ↔ 이익률) | `owner=리프, t:0, l:1` | `t:0, l:0`, `parent=그룹` | 헤더부터 데이터 끝까지 두 행 사이 가로선 제거 |

결합은 시각적 묶음일 뿐이다. 논리적 하위 관계까지 필요하면 `parent`도 위 항목으로 바꾼다.

## 4. 스키마

### 최상위

| 키 | 필수 | 설명 |
|---|---|---|
| `version` | 권장 | `"1.0"` |
| `id` | 선택 | 표 식별자. HTML `data-table-id`로 출력 |
| `title`, `unit` | 선택 | caption으로 출력. `unit`은 `(단위: …)` |
| `grid` | 필수 | `{rows, cols, headerRows, headerCols}` 모두 정수. `1 <= headerRows < rows`, `1 <= headerCols < cols` |
| `style` | 선택 | 아래 표 참고 |
| `corner` | 필수 | `{r:0, c:0, rs:headerRows, cs:headerCols, label}` |
| `colHeaders`, `rowHeaders` | 필수 | 헤더 배열 |
| `cells` | 필수 | 데이터 셀 배열 (순서 무관) |

### 헤더 객체 (`colHeaders[]`, `rowHeaders[]`)

| 키 | 설명 |
|---|---|
| `id` | 필수. 양 축 통틀어 유일. `corner`는 예약어 |
| `role` | 필수. `group` \| `leaf` \| `spacer` |
| `kind` | leaf 전용 선택. `value`(기본) \| `total` \| `delta` |
| `label` | 표시 텍스트. spacer는 금지 |
| `parent` | 선택. 같은 축의 group 또는 leaf id. 순환 금지 |
| `owner` | spacer 필수, 그 외 금지. 같은 축의 leaf id |
| `r`, `c` | 필수 |
| `rs`, `cs` | 생략 시 1 |
| `b` | `{t, l}` 각 0 또는 1. 생략 시 `{t:1, l:1}` |

### 데이터 셀 (`cells[]`)

| 키 | 설명 |
|---|---|
| `r`, `c` | 필수. 데이터 영역 좌표 |
| `rowKey` | 필수. **r이 같은** 행 leaf의 id |
| `colKey` | 필수. **c가 같은** 열 leaf의 id |
| `value` | **문자열**. 포맷까지 끝난 표시값 (`"1,250"`, `"+3.2%"`, `"-0.4%p"`) |
| `b` | 선택. 지정하면 t, l 둘 다 필요. 생략 시 리프 헤더에서 상속 |

### style (모두 선택)

`borderColor`(`#bfbdb5`), `borderWidth`(`1px`), `headerBg`(`#f5f4ef`), `fontFamily`, `fontSize`(`12px`), `cellPadding`(`6px 8px`), `spacerSize`(정수 px, 12).
문자, 숫자, `# . , % ( ) - '`, 공백만 허용한다. 그 외 문자가 있으면 기본값으로 대체된다.

**위 표에 없는 키는 쓰지 않는다.** Apex가 `JSON.deserializeStrict`로 파싱하므로 `rowspan`, `colspan`, `description` 같은 키는 바로 실패한다.

## 5. 작성 절차

1. **열 리프 목록을 왼쪽부터 확정**하고 `c = headerCols`부터 하나씩 번호를 매긴다. 기준 리프 바로 오른쪽에 그 delta를 둔다.
2. **행 리프 목록을 위부터 확정**하고 `r = headerRows`부터 번호를 매긴다. 상위 항목 바로 아래에 하위 항목을 둔다.
3. `grid.cols = headerCols + 열 리프 수`, `grid.rows = headerRows + 행 리프 수`.
4. `colHeaders` 작성: 상위(group) → 각 리프마다 spacer + leaf. 3장 레시피의 t/l을 복사한다.
5. `rowHeaders` 작성: 그룹(`rs` = 소속 리프 행 수) → 각 리프마다 spacer + leaf.
6. `cells` 작성: 모든 (행 리프 × 열 리프) 조합을 빠짐없이. `r`, `c`는 리프 좌표와 일치해야 한다.
7. 검증 스크립트 실행 후 오류가 0건일 때만 제출한다.

### ID 관례

열: 연도 `y24`, 분기 `l24_1q`, 계 `l24_tot`, delta `l25_qoq` / `l25_yoy`, spacer `cs_<리프id>`.
행: 그룹 `qcom`, 항목 `q_rev`, 하위 `q_qct`, spacer `rs_<리프id>`.
관례일 뿐 필수는 아니지만, 지키면 `rowKey`/`colKey` 실수가 줄어든다.

## 6. 분기 실적표 업무 규칙

보고 기준이 **Y년 Q분기**일 때:

- 열: `Y-1년 1Q~4Q, 계` / `Y년 1Q~Q분기`. QoQ, YoY 등 비교 지표는 **Q분기 리프의 delta**로 붙인다.
- Q = 4(연말)이고 연간 비교가 필요하면 `Y년 계`를 추가하고 그 아래 delta로 YoY(연간)를 붙인다.
- 계산: QoQ는 직전 분기 대비(1Q의 직전은 전년 4Q), YoY는 전년 동분기 대비. 금액 지표는 `%`, 비율 지표(이익률 등)는 차이를 `%p`로 표시한다.
- 비율 지표의 계는 분기 비율의 평균이 아니라 **연간 합계로 다시 계산**한다(예: 연간 영업이익 ÷ 연간 매출).
- 포맷: 금액은 천 단위 쉼표, 증감률·비율은 소수 1자리, 증감에는 부호(`+`/`-`), 0은 `0.0%`.

## 7. 검증

```bash
python scripts/matrix_table.py validate table.json           # Apex와 같은 규칙으로 검증
python scripts/matrix_table.py render table.json -o out.html  # Apex와 같은 구조의 HTML 미리보기
```

스크립트가 OK를 출력하지 않으면 제출하지 않는다. 오류 메시지는 Apex 오류 메시지와 같은 문구다.

## 8. 흔한 실수

- spacer를 그룹 하나에 하나만 두고 `cs`로 늘림 → spacer는 리프마다 하나, `rs=cs=1`이다.
- delta의 spacer `owner`를 delta 자신으로 지정 → 기준 리프(예: 2Q)를 가리켜야 ㄱ자 확장이 된다.
- 계의 spacer를 `t:1`로 둠 → 연도와 계 사이에 선이 생긴다. 계는 spacer와 leaf 모두 `t:0`이다.
- 행 하위 항목의 spacer를 `t:1`로 둠 → 상위 항목 확장이 끊긴다. 하위 항목 spacer는 `t:0`.
- 그룹 `rs`가 실제 리프 행 수와 다름 → 겹침 또는 빈 칸 오류.
- `value`를 숫자로 넣음 → 문자열로 넣는다.
- 결합 행에서 데이터 셀마다 `b`를 넣음 → 헤더 leaf/spacer의 `t:0`만으로 데이터 행까지 적용된다.

## 9. 예제

`examples/`의 세 파일은 모두 검증을 통과한 완성본이다. 비슷한 표를 만들 때 구조를 복사해 시작한다.

| 파일 | 기준 | 특징 |
|---|---|---|
| `sample_a_2025q2_peer.json` | 2025 2Q | 회사(퀄컴/소니) → 항목, 매출 아래 QCT/QTL, 영업이익–이익률 결합, 2Q 아래 QoQ |
| `sample_b_2025q3_single.json` | 2025 3Q | 그룹 레벨 없는 행 헤더(`headerCols=2`), 매출 아래 국내/해외, 3Q 아래 QoQ + YoY |
| `sample_c_2025q4_product.json` | 2025 4Q | 지표 그룹(매출/영업이익) → 제품, 4Q 아래 QoQ, 2025 계 아래 연간 YoY |
